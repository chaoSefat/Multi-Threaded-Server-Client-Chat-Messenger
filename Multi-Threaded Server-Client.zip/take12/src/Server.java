import java.io.*;
import java.util.*;
import java.net.*;
 
// Server class
public class Server 
{
 
    // Vector to store active clients
    static Vector<ClientHandler> ar = new Vector<>();
    public static Vector<String> usernames = new Vector<>();
    static Vector<String> passwords = new Vector<>();
    
     
    // counter for clients
    static int i = 0;
 
    public static void main(String[] args) throws IOException 
    {
        // server is listening on port 1234
        ServerSocket ss = new ServerSocket(1234);
         
        Socket s;
         
        // running infinite loop for getting
        // client request
        while (true) 
        {
            // Accept the incoming request
            boolean uexists = false;
            boolean pexists = false;
            s = ss.accept();
            
            System.out.println("New client request received : " + s);
             
            // obtain input and output streams
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());
           
            
            String x="";
            x=dis.readUTF();
            System.out.println(x);
            if(x.equals("signup")){
               String un="";
               String pass="";
               dos.writeUTF("Sign up with Username:password ");
               
               x = dis.readUTF();
               
               StringTokenizer sx = new StringTokenizer(x, ":");
               un = sx.nextToken();
               pass = sx.nextToken();
               
               for(int j = 0 ; j < usernames.size(); j++ ){
                   
                   if(un.equals(usernames.get(j))){
                   
                       uexists = true;
                   
                   } 
                   
                   if(pass.equals(passwords.get(j))){ 
                       
                       pexists = true;
                       
                   }
               
               }
               
               if(uexists!=true){
                    dos.writeUTF(un+" signed up with password "+pass);
               
          
                    
                    ClientHandler mtch = new ClientHandler(s,un, dis, dos);
                    usernames.add(un);
                    passwords.add(pass);
            // Create a new Thread with this object.
                    Thread t = new Thread(mtch);
             
                    System.out.println("Adding this client to active client list");
 
            // add this client to active clients list
                    ar.add(mtch);
 
            // start the thread.
                    t.start();
                    dos.writeUTF("Sign in successful!");
            
                i++;          
               }else{
                   System.out.println("");
                   dos.writeUTF("Username already exists!"); 
               }
            }
               
       }  
            
            
       
            //System.out.println("Creating a new handler for this client...");
            
            
            
            // increment i for new client.
            // i is used for naming only, and can be replaced
            // by any naming scheme
            
 
        
    }
}
 
// ClientHandler class
class ClientHandler implements Runnable 
{
    Scanner scn = new Scanner(System.in);
    private String name;
    final DataInputStream dis;
    final DataOutputStream dos;
    Socket s;
    boolean isloggedin;
     
    // constructor
    public ClientHandler(Socket s, String name,
                            DataInputStream dis, DataOutputStream dos) {
        this.dis = dis;
        this.dos = dos;
        this.name = name;
        this.s = s;
        this.isloggedin=true;
    }
    Vector<ClientHandler> ar = new Vector<>();
    @Override
    public void run() {
 
        String received;
        while (true) 
        {
            try
            {
                // receive the string
                received = dis.readUTF();
                 
                System.out.println(received);
                 
                if(received.equals("logout")){
                    //this.isloggedin=false;
                    //this.s.close();
                    break;
                    
                }
                if(received.equals("showlist")){
		    System.out.println("List of the users connected are \n");
			
			for(int i = 0; i < Server.usernames.size(); ++i) {
			   //ClientHandler  ct = ar.get(i);
			   //System.out.println((i+1) + "-> " + ar.get(i).name);
                           dos.writeUTF((i+1)+" -> "+ Server.usernames.get(i));
                           
                        }
			//break;
                }else{
                        
                // break the string into message and recipient part
                StringTokenizer st = new StringTokenizer(received, "@");
                String MsgToSend = st.nextToken();
                String recipient = st.nextToken();          
                int size=recipient.split(":").length;
                StringTokenizer size1 = new StringTokenizer(recipient, ":");
                String recipients[]=new String[size];
                for(int i=0;i<size;i++){
                    recipients[i]=size1.nextToken();
                }
                // search for the recipient in the connected devices list.
                // ar is the vector storing client of active users
                for (ClientHandler mc : Server.ar) 
                {
                    if (recipient.equals("all") && mc.isloggedin==true) 
                    {
                        mc.dos.writeUTF(this.name+" : "+MsgToSend);
                        
                    }            
                    // if the recipient is found, write on its
                    // output stream
                    else{
                   for(int i=0;i<size;i++){
                    if (mc.name.equals(recipients[i]) && mc.isloggedin==true) 
                    {
                        mc.dos.writeUTF(this.name+" : "+MsgToSend);
                        break;
                    }                 
                   }
                   }
                          
                }
            } 
            } catch (IOException e) {
                 
                e.printStackTrace();
            }
             
        }
        try
        {
            // closing resources
            this.dis.close();
            this.dos.close();
             
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}




